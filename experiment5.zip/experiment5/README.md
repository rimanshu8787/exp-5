# Experiment 5 — Redux Toolkit + Context API + useMemo

> Extension of Experiment 4

## Experiment 5 Updates

- ✅ Implemented **Redux Toolkit** (store, slice with 5 actions: `addTask`, `toggleTask`, `deleteTask`, `setFilter`, `setSearchQuery`)
- ✅ Added new page: **Reports** — full analytics dashboard powered by Redux state
- ✅ Added **useMemo** for:
  - Filtered + searched task list (Analytics page)
  - Category stats breakdown (Analytics page)
  - Complete report computation — completion rate, priority/category breakdown, critical pending (Reports page)
  - Home page summary stats
- ✅ Implemented **Context API** (`AppContext`) for global `theme` (light/dark) and `user` profile — used in Navbar, Footer, all pages
- ✅ Added screenshots in `/screenshots`

## Pages

| Route | Page | From |
|---|---|---|
| `/` | Home | Exp 3/4 |
| `/projects` | Projects | Exp 3 |
| `/analytics` | Analytics | Exp 4 |
| `/reports` | Reports | ✅ **Exp 5 NEW** |

## Folder Structure

```
src/
├── components/
│   ├── Navbar.jsx        ← uses useAppContext (theme + user)
│   ├── Footer.jsx        ← uses useAppContext (theme + user)
│   └── TaskCard.jsx      ← uses useDispatch (toggleTask, deleteTask)
├── context/
│   └── AppContext.jsx    ← theme + user global state
├── redux/
│   ├── store.js
│   └── slices/
│       └── taskSlice.js  ← addTask, toggleTask, deleteTask, setFilter, setSearchQuery
├── pages/
│   ├── Home.jsx          ← useSelector + useMemo (stats)
│   ├── Projects.jsx      ← useAppContext
│   ├── Analytics.jsx     ← useDispatch + useSelector + useMemo (filtered list)
│   └── Reports.jsx       ← useSelector + useMemo (full report) ✅ NEW
├── App.jsx
├── main.jsx
└── index.css
```

## Setup

```bash
npm install
npm run dev
```

## Screenshots

See `/screenshots` folder.

## Deployment

`{uid}-5-{name}.vercel.app`
