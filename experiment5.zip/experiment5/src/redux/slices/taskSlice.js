import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  tasks: [
    { id: 1, title: "Set up Redux Toolkit", category: "Dev", priority: "High", completed: true },
    { id: 2, title: "Implement useContext", category: "Dev", priority: "High", completed: true },
    { id: 3, title: "Build Reports Page", category: "Dev", priority: "Medium", completed: false },
    { id: 4, title: "Write README.md", category: "Docs", priority: "Low", completed: false },
    { id: 5, title: "Deploy to Vercel", category: "DevOps", priority: "High", completed: false },
    { id: 6, title: "Add screenshots folder", category: "Docs", priority: "Low", completed: false },
  ],
  filter: "All",
  searchQuery: "",
};

const taskSlice = createSlice({
  name: "tasks",
  initialState,
  reducers: {
    // Action 1
    addTask: (state, action) => {
      const newTask = {
        id: Date.now(),
        title: action.payload.title,
        category: action.payload.category || "General",
        priority: action.payload.priority || "Medium",
        completed: false,
      };
      state.tasks.push(newTask);
    },
    // Action 2
    toggleTask: (state, action) => {
      const task = state.tasks.find((t) => t.id === action.payload);
      if (task) task.completed = !task.completed;
    },
    // Action 3
    deleteTask: (state, action) => {
      state.tasks = state.tasks.filter((t) => t.id !== action.payload);
    },
    // Action 4
    setFilter: (state, action) => {
      state.filter = action.payload;
    },
    // Action 5
    setSearchQuery: (state, action) => {
      state.searchQuery = action.payload;
    },
  },
});

export const { addTask, toggleTask, deleteTask, setFilter, setSearchQuery } =
  taskSlice.actions;

export default taskSlice.reducer;
