import { useSelector } from "react-redux";
import { useMemo } from "react";
import { Link } from "react-router-dom";
import { useAppContext } from "../context/AppContext";

const Home = () => {
  const { theme, user } = useAppContext();
  const tasks = useSelector((state) => state.tasks.tasks);
  const isDark = theme === "dark";

  // useMemo — summary stats
  const stats = useMemo(() => {
    const total = tasks.length;
    const completed = tasks.filter((t) => t.completed).length;
    const pending = total - completed;
    const percent = total ? Math.round((completed / total) * 100) : 0;
    return { total, completed, pending, percent };
  }, [tasks]);

  const pageStyle = {
    minHeight: "calc(100vh - 64px - 72px)",
    padding: "3rem 2rem",
    maxWidth: "900px",
    margin: "0 auto",
  };

  const statCardStyle = (color) => ({
    background: isDark ? "rgba(255,255,255,0.04)" : "#ffffff",
    border: `1px solid ${color}33`,
    borderRadius: "16px",
    padding: "1.5rem",
    textAlign: "center",
    flex: 1,
    boxShadow: isDark ? "none" : "0 2px 12px rgba(0,0,0,0.06)",
  });

  return (
    <div style={pageStyle}>
      {/* Hero */}
      <div style={{ textAlign: "center", marginBottom: "3rem" }}>
        <div
          style={{
            width: "72px",
            height: "72px",
            borderRadius: "50%",
            background: "linear-gradient(135deg, #7c3aed, #3b82f6)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "1.8rem",
            margin: "0 auto 1rem",
          }}
        >
          {user.avatar}
        </div>
        <h1
          style={{
            fontSize: "2.2rem",
            fontWeight: "800",
            background: "linear-gradient(135deg, #7c3aed, #3b82f6)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            marginBottom: "0.5rem",
          }}
        >
          Welcome back, {user.name}!
        </h1>
        <p style={{ color: isDark ? "#a0aec0" : "#64748b", fontSize: "1.05rem" }}>
          {user.role} · Experiment 5 Dashboard
        </p>
      </div>

      {/* Stats — useMemo values */}
      <div style={{ display: "flex", gap: "1rem", marginBottom: "2.5rem", flexWrap: "wrap" }}>
        <div style={statCardStyle("#7c3aed")}>
          <p style={{ fontSize: "2rem", fontWeight: "800", color: "#7c3aed" }}>{stats.total}</p>
          <p style={{ color: isDark ? "#a0aec0" : "#64748b", fontSize: "0.9rem" }}>Total Tasks</p>
        </div>
        <div style={statCardStyle("#22c55e")}>
          <p style={{ fontSize: "2rem", fontWeight: "800", color: "#22c55e" }}>{stats.completed}</p>
          <p style={{ color: isDark ? "#a0aec0" : "#64748b", fontSize: "0.9rem" }}>Completed</p>
        </div>
        <div style={statCardStyle("#f59e0b")}>
          <p style={{ fontSize: "2rem", fontWeight: "800", color: "#f59e0b" }}>{stats.pending}</p>
          <p style={{ color: isDark ? "#a0aec0" : "#64748b", fontSize: "0.9rem" }}>Pending</p>
        </div>
        <div style={statCardStyle("#3b82f6")}>
          <p style={{ fontSize: "2rem", fontWeight: "800", color: "#3b82f6" }}>{stats.percent}%</p>
          <p style={{ color: isDark ? "#a0aec0" : "#64748b", fontSize: "0.9rem" }}>Progress</p>
        </div>
      </div>

      {/* Progress Bar */}
      <div
        style={{
          background: isDark ? "rgba(255,255,255,0.08)" : "#e2e8f0",
          borderRadius: "99px",
          height: "10px",
          marginBottom: "3rem",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            width: `${stats.percent}%`,
            height: "100%",
            background: "linear-gradient(90deg, #7c3aed, #3b82f6)",
            borderRadius: "99px",
            transition: "width 0.5s ease",
          }}
        />
      </div>

      {/* Quick Links */}
      <div style={{ display: "flex", gap: "1rem", flexWrap: "wrap", justifyContent: "center" }}>
        {[
          { to: "/projects", label: "📁 Projects", color: "#7c3aed" },
          { to: "/analytics", label: "📊 Analytics", color: "#3b82f6" },
          { to: "/reports", label: "📋 Reports", color: "#22c55e" },
        ].map((item) => (
          <Link
            key={item.to}
            to={item.to}
            style={{
              textDecoration: "none",
              background: `${item.color}15`,
              border: `1px solid ${item.color}40`,
              color: item.color,
              padding: "0.75rem 1.5rem",
              borderRadius: "12px",
              fontWeight: "600",
              fontSize: "0.95rem",
              transition: "all 0.2s",
            }}
          >
            {item.label}
          </Link>
        ))}
      </div>
    </div>
  );
};

export default Home;
