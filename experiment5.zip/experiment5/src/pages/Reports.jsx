import { useSelector } from "react-redux";
import { useMemo } from "react";
import { useAppContext } from "../context/AppContext";

const Reports = () => {
  const { theme, user } = useAppContext();
  const isDark = theme === "dark";
  const tasks = useSelector((state) => state.tasks.tasks);

  // useMemo — full analytics report computed from Redux state
  const report = useMemo(() => {
    const total = tasks.length;
    const completed = tasks.filter((t) => t.completed).length;
    const pending = total - completed;
    const completionRate = total ? ((completed / total) * 100).toFixed(1) : 0;

    // Priority breakdown
    const byPriority = tasks.reduce((acc, t) => {
      acc[t.priority] = (acc[t.priority] || { total: 0, done: 0 });
      acc[t.priority].total++;
      if (t.completed) acc[t.priority].done++;
      return acc;
    }, {});

    // Category breakdown
    const byCategory = tasks.reduce((acc, t) => {
      acc[t.category] = (acc[t.category] || { total: 0, done: 0 });
      acc[t.category].total++;
      if (t.completed) acc[t.category].done++;
      return acc;
    }, {});

    // High priority pending tasks
    const criticalPending = tasks.filter(
      (t) => !t.completed && t.priority === "High"
    );

    return { total, completed, pending, completionRate, byPriority, byCategory, criticalPending };
  }, [tasks]);

  const pageStyle = {
    minHeight: "calc(100vh - 64px - 72px)",
    padding: "3rem 2rem",
    maxWidth: "960px",
    margin: "0 auto",
  };

  const cardStyle = {
    background: isDark ? "rgba(255,255,255,0.04)" : "#ffffff",
    border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid #e2e8f0",
    borderRadius: "16px",
    padding: "1.5rem",
    boxShadow: isDark ? "none" : "0 2px 12px rgba(0,0,0,0.06)",
  };

  const labelStyle = {
    fontSize: "0.8rem",
    color: isDark ? "#a0aec0" : "#64748b",
    marginBottom: "4px",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
  };

  const priorityColors = { High: "#ef4444", Medium: "#f59e0b", Low: "#22c55e" };

  return (
    <div style={pageStyle}>
      {/* Header */}
      <div style={{ marginBottom: "2rem" }}>
        <h1
          style={{
            fontSize: "2rem",
            fontWeight: "800",
            background: "linear-gradient(135deg, #7c3aed, #3b82f6)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            marginBottom: "0.4rem",
          }}
        >
          📋 Reports
        </h1>
        <p style={{ color: isDark ? "#a0aec0" : "#64748b" }}>
          Generated for <strong style={{ color: "#7c3aed" }}>{user.name}</strong> · useMemo-powered insights from Redux state
        </p>
      </div>

      {/* Summary Row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "1rem", marginBottom: "1.5rem" }}>
        {[
          { label: "Total Tasks", value: report.total, color: "#7c3aed" },
          { label: "Completed", value: report.completed, color: "#22c55e" },
          { label: "Pending", value: report.pending, color: "#f59e0b" },
          { label: "Completion Rate", value: `${report.completionRate}%`, color: "#3b82f6" },
        ].map((s) => (
          <div key={s.label} style={{ ...cardStyle, textAlign: "center" }}>
            <p style={labelStyle}>{s.label}</p>
            <p style={{ fontSize: "2.2rem", fontWeight: "800", color: s.color }}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Overall Progress */}
      <div style={{ ...cardStyle, marginBottom: "1.5rem" }}>
        <p style={{ fontWeight: "700", marginBottom: "0.75rem", color: isDark ? "#e0e0f0" : "#1a1a2e" }}>
          Overall Progress
        </p>
        <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
          <div
            style={{
              flex: 1,
              height: "12px",
              background: isDark ? "rgba(255,255,255,0.08)" : "#e2e8f0",
              borderRadius: "99px",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                width: `${report.completionRate}%`,
                height: "100%",
                background: "linear-gradient(90deg, #7c3aed, #3b82f6)",
                borderRadius: "99px",
                transition: "width 0.5s",
              }}
            />
          </div>
          <span style={{ fontWeight: "700", color: "#7c3aed", minWidth: "50px" }}>
            {report.completionRate}%
          </span>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.5rem", marginBottom: "1.5rem" }}>
        {/* Priority Breakdown */}
        <div style={cardStyle}>
          <p style={{ fontWeight: "700", marginBottom: "1rem", color: isDark ? "#e0e0f0" : "#1a1a2e" }}>
            By Priority
          </p>
          {Object.entries(report.byPriority).map(([priority, data]) => {
            const pct = data.total ? Math.round((data.done / data.total) * 100) : 0;
            return (
              <div key={priority} style={{ marginBottom: "0.75rem" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                  <span style={{ fontSize: "0.85rem", color: priorityColors[priority], fontWeight: "600" }}>
                    {priority}
                  </span>
                  <span style={{ fontSize: "0.8rem", color: isDark ? "#a0aec0" : "#64748b" }}>
                    {data.done}/{data.total}
                  </span>
                </div>
                <div style={{ height: "6px", background: isDark ? "rgba(255,255,255,0.08)" : "#e2e8f0", borderRadius: "99px", overflow: "hidden" }}>
                  <div
                    style={{
                      width: `${pct}%`,
                      height: "100%",
                      background: priorityColors[priority],
                      borderRadius: "99px",
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Category Breakdown */}
        <div style={cardStyle}>
          <p style={{ fontWeight: "700", marginBottom: "1rem", color: isDark ? "#e0e0f0" : "#1a1a2e" }}>
            By Category
          </p>
          {Object.entries(report.byCategory).map(([cat, data]) => {
            const pct = data.total ? Math.round((data.done / data.total) * 100) : 0;
            return (
              <div key={cat} style={{ marginBottom: "0.75rem" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                  <span style={{ fontSize: "0.85rem", color: "#7c3aed", fontWeight: "600" }}>{cat}</span>
                  <span style={{ fontSize: "0.8rem", color: isDark ? "#a0aec0" : "#64748b" }}>
                    {data.done}/{data.total}
                  </span>
                </div>
                <div style={{ height: "6px", background: isDark ? "rgba(255,255,255,0.08)" : "#e2e8f0", borderRadius: "99px", overflow: "hidden" }}>
                  <div
                    style={{
                      width: `${pct}%`,
                      height: "100%",
                      background: "linear-gradient(90deg, #7c3aed, #3b82f6)",
                      borderRadius: "99px",
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Critical Pending (High Priority) */}
      <div style={cardStyle}>
        <p style={{ fontWeight: "700", marginBottom: "1rem", color: "#ef4444" }}>
          🚨 High Priority — Pending ({report.criticalPending.length})
        </p>
        {report.criticalPending.length === 0 ? (
          <p style={{ color: "#22c55e", fontWeight: "600" }}>✅ All high priority tasks are done!</p>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            {report.criticalPending.map((t) => (
              <div
                key={t.id}
                style={{
                  background: "rgba(239,68,68,0.08)",
                  border: "1px solid rgba(239,68,68,0.2)",
                  borderRadius: "10px",
                  padding: "0.6rem 1rem",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  fontSize: "0.9rem",
                  color: isDark ? "#e0e0f0" : "#1a1a2e",
                }}
              >
                <span style={{ color: "#ef4444" }}>⚠️</span>
                {t.title}
                <span
                  style={{
                    marginLeft: "auto",
                    fontSize: "0.75rem",
                    color: "#7c3aed",
                    background: "rgba(124,58,237,0.1)",
                    padding: "2px 8px",
                    borderRadius: "20px",
                  }}
                >
                  {t.category}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* useMemo badge */}
      <p
        style={{
          marginTop: "2rem",
          textAlign: "center",
          fontSize: "0.8rem",
          color: isDark ? "#444" : "#ccc",
        }}
      >
        ⚡ All report data computed via <code>useMemo</code> — recalculates only when Redux task state changes
      </p>
    </div>
  );
};

export default Reports;
