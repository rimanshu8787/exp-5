import { useAppContext } from "../context/AppContext";

const projects = [
  {
    id: 1,
    name: "Experiment 1 — SPA",
    tech: ["React", "Vite"],
    status: "Completed",
    desc: "Single Page Application with basic React components.",
  },
  {
    id: 2,
    name: "Experiment 3 — Router",
    tech: ["React Router", "Hooks"],
    status: "Completed",
    desc: "Multi-page app with React Router and custom hooks.",
  },
  {
    id: 3,
    name: "Experiment 4 — useReducer",
    tech: ["useReducer", "React"],
    status: "Completed",
    desc: "State management using useReducer for task tracking.",
  },
  {
    id: 4,
    name: "Experiment 5 — Redux Toolkit",
    tech: ["Redux Toolkit", "Context", "useMemo"],
    status: "In Progress",
    desc: "Advanced state management with Redux Toolkit + Context API.",
  },
];

const statusColors = {
  Completed: "#22c55e",
  "In Progress": "#f59e0b",
  Planned: "#3b82f6",
};

const Projects = () => {
  const { theme } = useAppContext();
  const isDark = theme === "dark";

  const pageStyle = {
    minHeight: "calc(100vh - 64px - 72px)",
    padding: "3rem 2rem",
    maxWidth: "900px",
    margin: "0 auto",
  };

  return (
    <div style={pageStyle}>
      <h1
        style={{
          fontSize: "2rem",
          fontWeight: "800",
          marginBottom: "0.5rem",
          background: "linear-gradient(135deg, #7c3aed, #3b82f6)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}
      >
        📁 Projects
      </h1>
      <p style={{ color: isDark ? "#a0aec0" : "#64748b", marginBottom: "2rem" }}>
        All experiments and projects from the course
      </p>

      <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
        {projects.map((p) => (
          <div
            key={p.id}
            style={{
              background: isDark ? "rgba(255,255,255,0.04)" : "#ffffff",
              border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid #e2e8f0",
              borderRadius: "16px",
              padding: "1.5rem",
              boxShadow: isDark ? "none" : "0 2px 12px rgba(0,0,0,0.06)",
              display: "flex",
              alignItems: "flex-start",
              gap: "1rem",
            }}
          >
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "0.5rem" }}>
                <h3 style={{ fontWeight: "700", fontSize: "1rem", color: isDark ? "#e0e0f0" : "#1a1a2e" }}>
                  {p.name}
                </h3>
                <span
                  style={{
                    fontSize: "0.75rem",
                    color: statusColors[p.status],
                    background: `${statusColors[p.status]}18`,
                    padding: "2px 10px",
                    borderRadius: "20px",
                    fontWeight: "600",
                  }}
                >
                  {p.status}
                </span>
              </div>
              <p style={{ fontSize: "0.9rem", color: isDark ? "#a0aec0" : "#64748b", marginBottom: "0.75rem" }}>
                {p.desc}
              </p>
              <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                {p.tech.map((t) => (
                  <span
                    key={t}
                    style={{
                      fontSize: "0.75rem",
                      color: "#7c3aed",
                      background: "rgba(124,58,237,0.1)",
                      padding: "2px 10px",
                      borderRadius: "20px",
                    }}
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Projects;
