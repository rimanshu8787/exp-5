import { useSelector, useDispatch } from "react-redux";
import { useMemo, useState } from "react";
import { addTask, setFilter, setSearchQuery } from "../redux/slices/taskSlice";
import { useAppContext } from "../context/AppContext";
import TaskCard from "../components/TaskCard";

const Analytics = () => {
  const dispatch = useDispatch();
  const { theme } = useAppContext();
  const isDark = theme === "dark";

  const { tasks, filter, searchQuery } = useSelector((state) => state.tasks);

  const [newTask, setNewTask] = useState({ title: "", category: "Dev", priority: "Medium" });

  // useMemo — filtered tasks based on filter + search
  const filteredTasks = useMemo(() => {
    let result = tasks;
    if (filter === "Completed") result = result.filter((t) => t.completed);
    if (filter === "Pending") result = result.filter((t) => !t.completed);
    if (searchQuery.trim()) {
      result = result.filter((t) =>
        t.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    return result;
  }, [tasks, filter, searchQuery]);

  // useMemo — category breakdown
  const categoryStats = useMemo(() => {
    const map = {};
    tasks.forEach((t) => {
      map[t.category] = (map[t.category] || 0) + 1;
    });
    return Object.entries(map).map(([cat, count]) => ({ cat, count }));
  }, [tasks]);

  const handleAdd = () => {
    if (!newTask.title.trim()) return;
    dispatch(addTask(newTask));
    setNewTask({ title: "", category: "Dev", priority: "Medium" });
  };

  const pageStyle = {
    minHeight: "calc(100vh - 64px - 72px)",
    padding: "3rem 2rem",
    maxWidth: "900px",
    margin: "0 auto",
  };

  const inputStyle = {
    background: isDark ? "rgba(255,255,255,0.06)" : "#f8fafc",
    border: isDark ? "1px solid rgba(255,255,255,0.12)" : "1px solid #e2e8f0",
    borderRadius: "10px",
    padding: "0.6rem 1rem",
    color: isDark ? "#e0e0f0" : "#1a1a2e",
    fontSize: "0.9rem",
    outline: "none",
    flex: 1,
  };

  const selectStyle = {
    ...inputStyle,
    flex: "none",
    cursor: "pointer",
  };

  return (
    <div style={pageStyle}>
      <h1
        style={{
          fontSize: "2rem",
          fontWeight: "800",
          marginBottom: "0.5rem",
          background: "linear-gradient(135deg, #7c3aed, #3b82f6)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}
      >
        📊 Analytics
      </h1>
      <p style={{ color: isDark ? "#a0aec0" : "#64748b", marginBottom: "2rem" }}>
        Manage tasks · Powered by Redux Toolkit + useMemo
      </p>

      {/* Category breakdown (useMemo) */}
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginBottom: "2rem" }}>
        {categoryStats.map(({ cat, count }) => (
          <div
            key={cat}
            style={{
              background: isDark ? "rgba(124,58,237,0.1)" : "rgba(124,58,237,0.07)",
              border: "1px solid rgba(124,58,237,0.25)",
              borderRadius: "10px",
              padding: "0.6rem 1.2rem",
              fontSize: "0.85rem",
              color: "#7c3aed",
              fontWeight: "600",
            }}
          >
            {cat}: {count}
          </div>
        ))}
      </div>

      {/* Add Task */}
      <div
        style={{
          background: isDark ? "rgba(255,255,255,0.04)" : "#ffffff",
          border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid #e2e8f0",
          borderRadius: "16px",
          padding: "1.25rem",
          marginBottom: "1.5rem",
          boxShadow: isDark ? "none" : "0 2px 12px rgba(0,0,0,0.06)",
        }}
      >
        <h3 style={{ fontWeight: "700", marginBottom: "1rem", fontSize: "0.95rem", color: isDark ? "#e0e0f0" : "#1a1a2e" }}>
          ➕ Add New Task
        </h3>
        <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
          <input
            style={{ ...inputStyle, minWidth: "180px" }}
            placeholder="Task title..."
            value={newTask.title}
            onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
            onKeyDown={(e) => e.key === "Enter" && handleAdd()}
          />
          <select style={selectStyle} value={newTask.category} onChange={(e) => setNewTask({ ...newTask, category: e.target.value })}>
            <option>Dev</option>
            <option>Docs</option>
            <option>DevOps</option>
            <option>General</option>
          </select>
          <select style={selectStyle} value={newTask.priority} onChange={(e) => setNewTask({ ...newTask, priority: e.target.value })}>
            <option>High</option>
            <option>Medium</option>
            <option>Low</option>
          </select>
          <button
            onClick={handleAdd}
            style={{
              background: "linear-gradient(135deg, #7c3aed, #3b82f6)",
              border: "none",
              borderRadius: "10px",
              padding: "0.6rem 1.4rem",
              color: "#fff",
              fontWeight: "700",
              cursor: "pointer",
              fontSize: "0.9rem",
            }}
          >
            Add
          </button>
        </div>
      </div>

      {/* Filter + Search */}
      <div style={{ display: "flex", gap: "10px", marginBottom: "1.25rem", flexWrap: "wrap" }}>
        <input
          style={{ ...inputStyle, maxWidth: "260px" }}
          placeholder="🔍 Search tasks..."
          value={searchQuery}
          onChange={(e) => dispatch(setSearchQuery(e.target.value))}
        />
        {["All", "Completed", "Pending"].map((f) => (
          <button
            key={f}
            onClick={() => dispatch(setFilter(f))}
            style={{
              background: filter === f ? "linear-gradient(135deg, #7c3aed, #3b82f6)" : "transparent",
              border: filter === f ? "none" : isDark ? "1px solid rgba(255,255,255,0.12)" : "1px solid #e2e8f0",
              borderRadius: "8px",
              padding: "0.5rem 1rem",
              color: filter === f ? "#fff" : isDark ? "#a0aec0" : "#64748b",
              cursor: "pointer",
              fontWeight: "600",
              fontSize: "0.85rem",
            }}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Task List (useMemo filtered) */}
      <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        {filteredTasks.length === 0 ? (
          <p style={{ color: isDark ? "#666" : "#aaa", textAlign: "center", padding: "2rem" }}>
            No tasks found.
          </p>
        ) : (
          filteredTasks.map((task) => <TaskCard key={task.id} task={task} />)
        )}
      </div>
    </div>
  );
};

export default Analytics;
