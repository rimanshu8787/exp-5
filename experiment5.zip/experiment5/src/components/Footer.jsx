import { useAppContext } from "../context/AppContext";

const Footer = () => {
  const { theme, user } = useAppContext();
  const isDark = theme === "dark";

  return (
    <footer
      style={{
        background: isDark ? "#0a0a1a" : "#1a1a2e",
        color: "#a0aec0",
        textAlign: "center",
        padding: "1.5rem",
        fontSize: "0.85rem",
        marginTop: "auto",
        borderTop: "1px solid rgba(124,58,237,0.3)",
      }}
    >
      <p>
        ⚡ Experiment 5 — Built with React + Redux Toolkit + Context API
      </p>
      <p style={{ marginTop: "4px", color: "#7c3aed" }}>
        Logged in as <strong>{user.name}</strong> · {user.role}
      </p>
    </footer>
  );
};

export default Footer;
