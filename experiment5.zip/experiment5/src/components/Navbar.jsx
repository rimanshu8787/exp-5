import { useState } from "react";
import { NavLink } from "react-router-dom";
import { useAppContext } from "../context/AppContext";

const Navbar = () => {
  const { theme, toggleTheme, user } = useAppContext();
  const [menuOpen, setMenuOpen] = useState(false);

  const isDark = theme === "dark";

  const navStyle = {
    background: isDark
      ? "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)"
      : "linear-gradient(135deg, #ffffff 0%, #f0f4ff 100%)",
    boxShadow: isDark
      ? "0 2px 20px rgba(124,58,237,0.3)"
      : "0 2px 20px rgba(0,0,0,0.1)",
    padding: "0 2rem",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    height: "64px",
    position: "sticky",
    top: 0,
    zIndex: 100,
    borderBottom: isDark ? "1px solid rgba(124,58,237,0.2)" : "1px solid #e2e8f0",
  };

  const logoStyle = {
    fontSize: "1.4rem",
    fontWeight: "800",
    background: "linear-gradient(135deg, #7c3aed, #3b82f6)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    letterSpacing: "-0.5px",
  };

  const linkStyle = ({ isActive }) => ({
    textDecoration: "none",
    color: isActive ? "#7c3aed" : isDark ? "#a0aec0" : "#64748b",
    fontWeight: isActive ? "600" : "500",
    fontSize: "0.9rem",
    padding: "6px 14px",
    borderRadius: "8px",
    background: isActive
      ? isDark
        ? "rgba(124,58,237,0.15)"
        : "rgba(124,58,237,0.1)"
      : "transparent",
    transition: "all 0.2s",
  });

  const links = [
    { to: "/", label: "Home" },
    { to: "/projects", label: "Projects" },
    { to: "/analytics", label: "Analytics" },
    { to: "/reports", label: "Reports" },
  ];

  return (
    <nav style={navStyle}>
      <span style={logoStyle}>⚡ Exp5</span>

      {/* Desktop Links */}
      <div style={{ display: "flex", gap: "4px", alignItems: "center" }}>
        {links.map((l) => (
          <NavLink key={l.to} to={l.to} end={l.to === "/"} style={linkStyle}>
            {l.label}
          </NavLink>
        ))}
      </div>

      {/* Right side: user + theme toggle */}
      <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
        {/* User Avatar (Context) */}
        <div
          title={`${user.name} — ${user.role}`}
          style={{
            width: "36px",
            height: "36px",
            borderRadius: "50%",
            background: "linear-gradient(135deg, #7c3aed, #3b82f6)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#fff",
            fontWeight: "700",
            fontSize: "0.8rem",
            cursor: "default",
          }}
        >
          {user.avatar}
        </div>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          style={{
            background: isDark ? "rgba(124,58,237,0.2)" : "rgba(124,58,237,0.1)",
            border: "1px solid rgba(124,58,237,0.3)",
            borderRadius: "8px",
            padding: "6px 12px",
            cursor: "pointer",
            color: isDark ? "#e0e0f0" : "#1a1a2e",
            fontSize: "1rem",
            transition: "all 0.2s",
          }}
        >
          {isDark ? "☀️" : "🌙"}
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
