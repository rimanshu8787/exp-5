import { useDispatch } from "react-redux";
import { toggleTask, deleteTask } from "../redux/slices/taskSlice";
import { useAppContext } from "../context/AppContext";

const priorityColors = {
  High: "#ef4444",
  Medium: "#f59e0b",
  Low: "#22c55e",
};

const TaskCard = ({ task }) => {
  const dispatch = useDispatch();
  const { theme } = useAppContext();
  const isDark = theme === "dark";

  const cardStyle = {
    background: isDark
      ? task.completed
        ? "rgba(124,58,237,0.05)"
        : "rgba(255,255,255,0.04)"
      : task.completed
      ? "rgba(124,58,237,0.05)"
      : "#ffffff",
    border: isDark
      ? `1px solid ${task.completed ? "rgba(124,58,237,0.3)" : "rgba(255,255,255,0.08)"}`
      : `1px solid ${task.completed ? "rgba(124,58,237,0.3)" : "#e2e8f0"}`,
    borderRadius: "12px",
    padding: "1rem 1.2rem",
    display: "flex",
    alignItems: "center",
    gap: "12px",
    transition: "all 0.2s",
    opacity: task.completed ? 0.75 : 1,
  };

  return (
    <div style={cardStyle}>
      {/* Checkbox */}
      <input
        type="checkbox"
        checked={task.completed}
        onChange={() => dispatch(toggleTask(task.id))}
        style={{ width: "18px", height: "18px", accentColor: "#7c3aed", cursor: "pointer" }}
      />

      {/* Task Info */}
      <div style={{ flex: 1 }}>
        <p
          style={{
            fontWeight: "500",
            textDecoration: task.completed ? "line-through" : "none",
            color: task.completed
              ? isDark
                ? "#666"
                : "#aaa"
              : isDark
              ? "#e0e0f0"
              : "#1a1a2e",
            fontSize: "0.95rem",
          }}
        >
          {task.title}
        </p>
        <div style={{ display: "flex", gap: "8px", marginTop: "4px" }}>
          <span
            style={{
              fontSize: "0.75rem",
              color: "#7c3aed",
              background: "rgba(124,58,237,0.1)",
              padding: "2px 8px",
              borderRadius: "20px",
            }}
          >
            {task.category}
          </span>
          <span
            style={{
              fontSize: "0.75rem",
              color: priorityColors[task.priority],
              background: `${priorityColors[task.priority]}15`,
              padding: "2px 8px",
              borderRadius: "20px",
            }}
          >
            {task.priority}
          </span>
        </div>
      </div>

      {/* Delete */}
      <button
        onClick={() => dispatch(deleteTask(task.id))}
        style={{
          background: "rgba(239,68,68,0.1)",
          border: "1px solid rgba(239,68,68,0.3)",
          borderRadius: "8px",
          padding: "4px 10px",
          cursor: "pointer",
          color: "#ef4444",
          fontSize: "0.85rem",
          transition: "all 0.2s",
        }}
      >
        🗑
      </button>
    </div>
  );
};

export default TaskCard;
